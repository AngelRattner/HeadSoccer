﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace head_soccer
{
    class hits
    {
        public static bool Hit(Image player,Image ball)
        {
            //get the canter of the pics
            double canter_of_player_top = Canvas.GetTop(player) + (player.ActualHeight / 2);//center of top of player
            double canter_of_player_left = Canvas.GetLeft(player) + (player.ActualWidth / 2);//center of left plyer
            double canter_of_ball_top = Canvas.GetTop(ball) + (ball.ActualHeight / 2);//cntr of top ball
            double canter_of_ball_left = Canvas.GetLeft(ball) + (ball.ActualWidth / 2);//ctr of left ball
            //radius
            double player_rdi = canter_of_player_left - Canvas.GetLeft(player);//rad of player
            double ball_rdi = canter_of_ball_left - Canvas.GetLeft(ball);//rad of ball
            //dustans between chrecters =sqer((y-y')^2+(x-x')^2)
            double dist= Math.Sqrt(((canter_of_player_left -canter_of_ball_left)*(canter_of_player_left - canter_of_ball_left))+(canter_of_ball_top -canter_of_player_top)* (canter_of_ball_top - canter_of_player_top));
            //colisen happen when dist= ball and player rad togter
            double min_val_for_hit = player_rdi + ball_rdi;
            if (dist <= min_val_for_hit) return true;
            else return false;
        }

        
        //        public static bool iscolidright(Image img, Image img_ball) //hit from left
        //        {
        //            double toprx = Canvas.GetLeft(img) + img.ActualWidth;
        //            double topry = Canvas.GetTop(img);
        //            if (MainPage.IsHitBall(img_ball, toprx, topry)) return true;
        //            //---------------------------------3
        //            double toplx = Canvas.GetLeft(img);
        //            double toply = Canvas.GetTop(img);
        //            if (MainPage.IsHitBall(img_ball, toplx, toply)) return true;
        //            //=================2
        //            double botrx = Canvas.GetTop(img) + img.ActualWidth;
        //            double botry = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img_ball, botrx, botry)) return true;
        //            //===================4
        //            double botlx = Canvas.GetLeft(img);
        //            double botly = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img_ball, botlx, botly)) return true;

        //            else return false;
        //        }
        //        public static bool iscolidleft(Image img, Image img_ball) //hit from right
        //        {
        //            double toprx = Canvas.GetLeft(img);
        //            double topry = Canvas.GetTop(img);
        //            if (MainPage.IsHitBall(img, toprx, topry)) return true;
        //            //---------------------------------3
        //            double toplx = Canvas.GetLeft(img) + img.ActualWidth;
        //            double toply = Canvas.GetTop(img);
        //            if (MainPage.IsHitBall(img, toplx, toply)) return true;
        //            //=================2
        //            double botrx = Canvas.GetTop(img);
        //            double botry = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img, botrx, botry)) return true;
        //            //===================4
        //            double botlx = Canvas.GetLeft(img) + img.ActualWidth;
        //            double botly = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img_ball, botlx, botly)) return true;
        //            else return false;
        //        }
        //        public static bool iscoliup(Image img, Image img_ball) //hit under the ball
        //        {
        //            double toprx = Canvas.GetLeft(img);
        //            double topry = Canvas.GetTop(img);
        //            if (MainPage.IsHitBall(img , toprx, topry)) return true;
        //            //---------------------------------3
        //            double toplx = Canvas.GetLeft(img);
        //            double toply = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img, toplx, toply)) return true;
        //            //=================2
        //            double botrx = Canvas.GetTop(img) + img.ActualWidth;
        //            double botry = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img, botrx, botry)) return true;
        //            //===================4
        //            double botlx = Canvas.GetLeft(img) + img.ActualWidth;
        //            double botly = Canvas.GetTop(img) + img.ActualHeight;
        //            if (MainPage.IsHitBall(img_ball, botlx, botly)) return true;
        //            else return false;
        //        }
        //public static bool iscolidown(Image img, Image img_ball) //above the ball ...can be?
        //{
        //    double toprx = Canvas.GetLeft(img);
        //    double topry = Canvas.GetTop(img)+img.ActualHeight;
        //    if (MainPage.IsHitBall(img, toprx, topry)) return true;
        //    //---------------------------------3
        //    double toplx = Canvas.GetLeft(img);
        //    double toply = Canvas.GetTop(img);
        //    if (MainPage.IsHitBall(img, toplx, toply)) return true;
        //    //=================2
        //    double botrx = Canvas.GetTop(img) + img.ActualWidth;
        //    double botry = Canvas.GetTop(img) + img.ActualHeight;
        //    if (MainPage.IsHitBall(img, botrx, botry)) return true;
        //    //===================4
        //    double botlx = Canvas.GetLeft(img) + img.ActualWidth;
        //    double botly = Canvas.GetTop(img);
        //    if (MainPage.IsHitBall(img_ball, botlx, botly)) return true;
        //    else return false;
        //        }
    }
}
