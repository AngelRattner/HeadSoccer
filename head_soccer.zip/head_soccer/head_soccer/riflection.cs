﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace head_soccer
{
    class riflection
    {
        public static double proportion(Image ball, Image player)
        {
            //get the canter of the pics
            double canter_of_player_top = Canvas.GetTop(player) + (player.ActualHeight / 2);//center of top of player
            double canter_of_player_left = Canvas.GetLeft(player) + (player.ActualWidth / 2);//center of left plyer
            double canter_of_ball_top = Canvas.GetTop(ball) + (ball.ActualHeight / 2);//cntr of top ball
            double canter_of_ball_left = Canvas.GetLeft(ball) + (ball.ActualWidth / 2);//ctr of left ball
            //find the insline ?=y-y1/x-x1
            double a = ((canter_of_ball_top - canter_of_player_top) / (canter_of_ball_left - canter_of_player_left));
            return a;
        }

        internal static double proportion(Image img_ball, UIElement img_me)
        {
            throw new NotImplementedException();
        }
    }
}
