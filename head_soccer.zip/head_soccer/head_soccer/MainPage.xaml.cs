﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Core;
using Windows.UI.Xaml.Navigation;
using Windows.ApplicationModel;
using Windows.UI.Xaml.Media.Imaging;
using Windows.Networking;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace head_soccer
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        DispatcherTimer time = new DispatcherTimer();
        double tickconter = 0, stop = 1;//stop how fast ball stop 
        int num = 1, time_to_fall = 0, airtime = 0, dontmove = 0, digoal = 0;
        //digaol =timer for goal image ,num =timer for timer,airtime=ck if ball jump again,
        //dont move=stop ai,time to fall=when ball stop go up
        int mypoint = 0, Aipoint = 0;//keep track after point
        bool isjump = false, aijump = false;//ck if i am jump
        bool bounce = false, delay = false;//ck if ball need to bounce
        bool resat = false; //know when to stop the bonc of the ball
        double gravity, antigravity;  //force that make ball fall and go up
        double velocity = 25; //velocity in left\right movment 
        bool part1 = false, part2 = false, part3 = false, part4 = false, part5 = false, part6 = false, part7 = false, part8 = false;//part is x/8 cer
        bool part11 = false, part12 = false, part13 = false, part14 = false, part15 = false, part16 = false, part17 = false, part18 = false;//part is x/8 of op cer
        bool apper = false;
        List<string> keys = new List<string>();

        public MainPage()
        {
            this.InitializeComponent();
            wishel.Play();
            Window.Current.CoreWindow.KeyDown += KeyDown;
            Window.Current.CoreWindow.KeyUp += KeyUp;
            time.Tick += GameLoop;
            time.Interval = new TimeSpan(0, 0, 0, 0, 10);
            time.Start();
        }
        private void GameLoop(object sender, object e)
        {
            PlayerMovment();
            BallMovement();
            score();
            AiMovement();
        }
        public void AiMovement()
        {
            if (main_menu.MultyPlayer == false)
            {//ai play
                if (hits.Hit(img_ai, img_ball) == true) delay = true;//ck if ai hit the ball
                if (delay == true) dontmove++;//counter for not moving
                if (dontmove == 30)
                {
                    delay = false;//resat the condition
                    dontmove = 0;//resat conter
                }
                if (Canvas.GetTop(img_ai) >= 547) aijump = false;//not jumo , u can
                if (Canvas.GetTop(img_ai) <= 247) aijump = true;//max higt start fall
                if (Canvas.GetTop(img_ai) < 547) Canvas.SetTop(img_ai, Canvas.GetTop(img_ai) + 5);//player fall
                if (dontmove == 0)//stop the ai for a moment after hitting the  ball
                {
                    if (Canvas.GetLeft(img_ai) > Canvas.GetLeft(img_ball)) Canvas.SetLeft(img_ai, Canvas.GetLeft(img_ai) - 8);//go to ball from right
                    else Canvas.SetLeft(img_ai, Canvas.GetLeft(img_ai) + 8);//goto to ball from left
                    if (Canvas.GetTop(img_ai) - Canvas.GetTop(img_ball) <= 300 && Canvas.GetTop(img_ai) - Canvas.GetTop(img_ball) >= 0)
                        if (aijump == false) Canvas.SetTop(img_ai, Canvas.GetTop(img_ai) - 8);//to be able to jumo biger then gravity
                }//jump to ball
            } //ai play
            else //multyplayer
            {
                // player gravity and jump abiliity/////////////////////////////////////////////////////////
                if (Canvas.GetTop(img_ai) == 547) aijump = false;//not jumo , u can
                if (Canvas.GetTop(img_ai) == 247) aijump = true;//max higt start fall
                if (Canvas.GetTop(img_ai) < 547 && !keys.Contains("W")) aijump = true;//space is not prees start fall and not able to jump more
                if (Canvas.GetTop(img_ai) < 547) Canvas.SetTop(img_ai , Canvas.GetTop(img_ai) + 5);//player fall



                if (keys.Contains("A"))
                {
                    if (Canvas.GetLeft(img_ai) > 0)
                    {
                        Canvas.SetLeft(img_ai, Canvas.GetLeft(img_ai) - 15);
                    }
                }
                else if (keys.Contains("D"))
                {
                    if (Canvas.GetLeft(img_ai) + 5 + img_ball.ActualWidth <= 1400)
                    {
                        Canvas.SetLeft(img_ai, Canvas.GetLeft(img_ai) + 15);
                    }
                }
                if (keys.Contains("W"))
                {
                    if (aijump == false)
                    {
                        if (Canvas.GetTop(img_ai) > 247)
                        {
                            Canvas.SetTop(img_ai, Canvas.GetTop(img_ai) - 15);
                        }
                    }
                }
            }//2 players
        }
        public void score()
        {
            tickconter += 1; //game timer
            if (tickconter % 30 == 0)
            {
                timer_clock.Text = num.ToString();
                num++;
                if (num == 90) Frame.Navigate(typeof(pause));
            }//timer

            //right side goal
            if (Canvas.GetLeft(img_ball) > 1390 && Canvas.GetTop(img_ball) > 247) //right side goal!!
            {
                goal.Play();
                apper = true;
                mypoint++;
                //resat all the imgs
                Canvas.SetLeft(img_ball, 730);
                Canvas.SetTop(img_ball, 140);
                Canvas.SetLeft(img_me, 140);
                Canvas.SetTop(img_me, 547);
                Canvas.SetLeft(img_ai, 1254);
                Canvas.SetTop(img_ai, 547);
                velocity = 0;//stop the ball and reset his speed
                part1 = false; part2 = false; part3 = false; part4 = false; part5 = false; part6 = false; part7 = false; part8 = false;
                part11 = false; part12 = false; part13 = false; part14 = false; part15 = false; part16 = false; part17 = false; part18 = false;
            }
            //left side goal
            if (Canvas.GetLeft(img_ball) < 26 && Canvas.GetTop(img_ball) > 247)//left side goal...
            {
                goal.Play();
                apper = true;
                Aipoint++;
                //re set all imgs
                Canvas.SetLeft(img_ball, 730);
                Canvas.SetTop(img_ball, 140);
                Canvas.SetLeft(img_me, 140);
                Canvas.SetTop(img_me, 547);
                Canvas.SetLeft(img_ai, 1254);
                Canvas.SetTop(img_ai, 547);
                velocity = 0;//stop the ball and reset his speed
                part1 = false; part2 = false; part3 = false; part4 = false; part5 = false; part6 = false; part7 = false; part8 = false;
                part11 = false; part12 = false; part13 = false; part14 = false; part15 = false; part16 = false; part17 = false; part18 = false;
            }
            if (apper)
            {
                img_goal.Visibility = Visibility.Visible;
                digoal++;
                if (digoal == 20)
                {
                    img_goal.Visibility = Visibility.Collapsed;
                    apper = false;
                    digoal = 0;
                    wishel.Play();
                }
            }
            //my score..right side
            if (mypoint == 1) myscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/1.jpeg"));
            if (mypoint == 2) myscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/2.jpeg"));
            if (mypoint == 3) myscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/3.jpeg"));
            if (mypoint == 4) myscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/4.jpeg"));
            if (mypoint == 5)
            {
                myscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/5.jpeg"));
                ExitGame(typeof(winner));
            }
            //ai score point..left side
            if (Aipoint == 1) aiscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/1.jpeg"));
            if (Aipoint == 2) aiscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/2.jpeg"));
            if (Aipoint == 3) aiscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/3.jpeg"));
            if (Aipoint == 4) aiscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/4.jpeg"));
            if (Aipoint == 5)
            {
                aiscore.Source = new BitmapImage(new Uri("ms-appx:///Assets/5.jpeg"));
                ExitGame(typeof(loser));
            }
        }
        private void BallMovement()
        {
            gravity = Canvas.GetTop(img_ball) * (0.02);//g*h (change lower=faster)
            antigravity = gravity * 2; //force the ball to jump
            //hit at the top of the gate
            if (Canvas.GetLeft(img_ball) <= 50 && Canvas.GetTop(img_ball) <= 248 && Canvas.GetTop(img_ball) >= 232)//above left gate
            {
                Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + 5);
            }
            else if (Canvas.GetLeft(img_ball) >= 1350 && Canvas.GetTop(img_ball) <= 248 && Canvas.GetTop(img_ball) >= 232)//above right gate
            {
                Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - 5);
            }

            //ball gravity
            else if (Canvas.GetTop(img_ball) < 547) //at any point int the air the ball fall
            {
                Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) + gravity);//ball fall to grond
                airtime++;
                if (Canvas.GetTop(img_ball) < 0) Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) + 100);//if ball is out of screen
            }

            //dose ball need to bounce
            if (airtime > 30 && Canvas.GetTop(img_ball) >= 547)
            {
                bounce = true;
            }
            if (bounce && airtime > 0)
            {
                Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - (antigravity*0.8));
                airtime -= 3;
                resat = true;
            }
            if (resat==true && airtime <= 0)
            {
                airtime = 0;
                bounce = false;
            }

            //make suer the ball is inside the screen
            if (Canvas.GetLeft(img_ball) > 0 && Canvas.GetLeft(img_ball) < 1500)
            {
                //ck if ball got hit by player
                #region 
                if (hits.Hit(img_me, img_ball) == true)  //hit by real player
                {
                    if (Canvas.GetLeft(img_ball) == Canvas.GetLeft(img_me)) //ck if the ball and player have same x it caus divd by 0 and error..
                    {
                        if (Canvas.GetTop(img_ball) >= Canvas.GetTop(img_me)) if (Canvas.GetTop(img_ball) < 547) Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) + velocity);//player on top
                            else Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - velocity);//ball on top
                    }
                    else
                    {
                        double a = riflection.proportion(img_ball, img_me);//get the angel of the hit (a)
                        if (a >= 0 && a <= 1 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_me)) part1 = true;         //betwwen 45 dag to 0, first 1/8 of cercale, hit from right/   left of ball is bigger
                        else if (a > 1 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_me)) part2 = true;             //bet 45 to infin,2/8 of cer right/    left of ball is bigger
                        else if (a <= -1 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_me)) part3 = true;            //bet -45 to -infi 3/8 of cer,left /   left of ball is smaller
                        else if (a > -1 && a < 0 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_me)) part4 = true;   //bet 0 to -45 4/8 cer, left/   left of ball is smaller
                        else if (a > 0 && a < 1 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_me)) part5 = true;    //bet 0 to 45 5/8 cer but hit from left/    left of ball is smaller
                        else if (a >= 1 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_me)) part6 = true;             //bet 45 to inf 6/8 cer hit from left/    left of ball is smaller
                        else if (a <= -1 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_me)) part7 = true;            // bet -45 to inf 7/8 cer hit from right/   left of ball is bigger
                        else if (a > -1 && a < 0 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_me)) part8 = true;   //bet -45 to 0 8/8 of cer right/   left of ball is bigger
                                                                                                                       //now i know were the ball got hit
                    }
                }
                if (part1) //go right
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part2)
                {
                    time_to_fall++;
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - antigravity);
                    velocity -= stop;
                    if (time_to_fall == 30) antigravity = 0;//stop go up
                }
                else if (part3)
                {
                    time_to_fall++;
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - antigravity);
                    velocity -= stop;
                    if (time_to_fall == 30) antigravity = 0;//stop go up
                }
                else if (part4)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part5)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part6)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part7)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    velocity -= stop;
                }
                else if (part8)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    velocity -= stop;
                }

                if (velocity == 0)//if stop move
                {
                    part1 = false; part2 = false; part3 = false; part4 = false; part5 = false; part6 = false; part7 = false; part8 = false;
                    velocity = 25;//reset speed and condi
                    antigravity = gravity * 2;
                }
                #endregion
                //ck if ball hit by ai
                #region 
                if (hits.Hit(img_ai, img_ball) == true)  //hit by real player
                {
                    if (Canvas.GetLeft(img_ball) == Canvas.GetLeft(img_ai)) //ck if the ball and player have same x it caus divd by 0 and error..
                    {
                        if (Canvas.GetTop(img_ball) >= Canvas.GetTop(img_ai)) if (Canvas.GetTop(img_ball) < 547) Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) + velocity);//player on top
                            else Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - velocity);//ball on top
                    }
                    else
                    {
                        double a = riflection.proportion(img_ball, img_ai);//get the angel of the hit (a)
                        if (a >= 0 && a <= 1 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_ai)) part11 = true;         //betwwen 45 dag to 0, first 1/8 of cercale, hit from right/   left of ball is bigger
                        else if (a > 1 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_ai)) part12 = true;             //bet 45 to infin,2/8 of cer right/    left of ball is bigger
                        else if (a <= -1 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_ai)) part13 = true;            //bet -45 to -infi 3/8 of cer,left /   left of ball is smaller
                        else if (a > -1 && a < 0 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_ai)) part14 = true;   //bet 0 to -45 4/8 cer, left/   left of ball is smaller
                        else if (a > 0 && a < 1 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_ai)) part15 = true;    //bet 0 to 45 5/8 cer but hit from left/    left of ball is smaller
                        else if (a >= 1 && Canvas.GetLeft(img_ball) < Canvas.GetLeft(img_ai)) part16 = true;             //bet 45 to inf 6/8 cer hit from left/    left of ball is smaller
                        else if (a <= -1 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_ai)) part17 = true;            // bet -45 to inf 7/8 cer hit from right/   left of ball is bigger
                        else if (a > -1 && a < 0 && Canvas.GetLeft(img_ball) > Canvas.GetLeft(img_ai)) part18 = true;   //bet -45 to 0 8/8 of cer right/   left of ball is bigger
                                                                                                                        //now i know were the ball got hit
                    }
                }
                if (part11) //go left
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part12)
                {
                    time_to_fall++;
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - antigravity);
                    velocity -= stop;
                    if (time_to_fall == 30) antigravity = 0;//stop go up
                }
                else if (part13)
                {
                    time_to_fall++;
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - antigravity);
                    velocity -= stop;
                    if (time_to_fall == 30) antigravity = 0;//stop go up
                }
                else if (part14)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    Canvas.SetTop(img_ball, Canvas.GetTop(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part15)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    velocity -= stop;
                }
                else if (part16)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) + velocity);
                    velocity -= stop;
                }
                else if (part17)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    velocity -= stop;
                }
                else if (part18)
                {
                    Canvas.SetLeft(img_ball, Canvas.GetLeft(img_ball) - velocity);
                    velocity -= stop;
                }

                if (velocity == 0)//if stop move
                {
                    part11 = false; part12 = false; part13 = false; part14 = false; part15 = false; part16 = false; part17 = false; part18 = false;
                    velocity = 25;//reset speed and condi
                    antigravity = gravity * 2;
                }
                #endregion
            }
        }
        private void PlayerMovment()
        {
            // player gravity and jump abiliity/////////////////////////////////////////////////////////
            if (Canvas.GetTop(img_me) == 547) isjump = false;//not jumo , u can
            if (Canvas.GetTop(img_me) == 247) isjump = true;//max higt start fall
            if (Canvas.GetTop(img_me) < 547 && !keys.Contains("Space") ) isjump = true;//space is not prees start fall and not able to jump more
            if (Canvas.GetTop(img_me) < 547) Canvas.SetTop(img_me, Canvas.GetTop(img_me) + 5);//player fall


            if (keys.Contains("Left"))
            {
                if (Canvas.GetLeft(img_me) > 0)
                {
                    Canvas.SetLeft(img_me, Canvas.GetLeft(img_me) - 15);
                }
            }
            else if (keys.Contains("Right"))
            {
                if (Canvas.GetLeft(img_me) + 5 + img_ball.ActualWidth <= 1400)
                {
                    Canvas.SetLeft(img_me, Canvas.GetLeft(img_me) + 15);
                }
            }
            if (keys.Contains("Space"))
            {
                if (isjump == false)
                {
                    if (Canvas.GetTop(img_me) > 247)
                    {
                        Canvas.SetTop(img_me, Canvas.GetTop(img_me) - 15);
                    }
                }
            }
             if (keys.Contains("Escape"))
            {
                Frame.Navigate(typeof(pause));
            }
        }
        private new void KeyDown(CoreWindow sender, KeyEventArgs args) //event of buttens press
        {
            //key = args.VirtualKey.ToString();
            keys.Add(args.VirtualKey.ToString());
        }
        private new void KeyUp(CoreWindow sender, KeyEventArgs args)//event of stop pres
        {
            //key = "";
            // keys.Remove(args.VirtualKey.ToString());
            keys.RemoveAll(str => str == args.VirtualKey.ToString());
        }
        static public bool IsHitBall(Image ball, double leftp, double topp) //dose player hit ball?
        {
            if (leftp < Canvas.GetLeft(ball) + ball.ActualWidth && leftp > Canvas.GetLeft(ball)
                && topp < Canvas.GetTop(ball) + ball.ActualHeight && topp < Canvas.GetTop(ball))
            {
                return true;//yes
            }
            else return false;//no
        }
        private void ExitGame(Type viewType)
        {
            time.Stop();
            Frame.Navigate(viewType);
        } //CHANGE SCREEN

    }
}
