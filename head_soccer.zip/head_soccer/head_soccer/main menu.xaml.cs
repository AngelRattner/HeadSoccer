﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Input;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Text.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.UI;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace head_soccer
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class main_menu : Page
    {
        static public bool MultyPlayer=false;
        public main_menu()
        {
            this.InitializeComponent();
            keySound.Play();
        }

        private void start_game_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MainPage));
            wishel.Play();
        }
        private void MousEnter(object sender,MouseEventArgs e)
        {
            start_game.Width += 6;
            start_game.Height += 3;
        }
        private void MousLeave(object sender,MouseEventArgs e)
        {
            start_game.Width -= 6;
            start_game.Height -= 3;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (help_text.Visibility == Visibility.Collapsed) help_text.Visibility = Visibility.Visible;
            else help_text.Visibility = Visibility.Collapsed;
        }

        private void _2PLAYER_Checked(object sender, RoutedEventArgs e)
        {
            MultyPlayer = true;
        }

        private void _2PLAYER_Unchecked(object sender, RoutedEventArgs e)
        {
            MultyPlayer = false;
        }
    }
}
